/*
	In order to run this file, please run from this directory
	docker run --rm -v $(pwd):/app -w /app node node prime_funzioni.js
*/

// Array piatto
function flatten_array(array){
    if(!Array.isArray(array))
        return array

    let result = []
    for(let i = 0; i < array.length; i++){
        el = array[i]
        if(Array.isArray(el)){
            el = flatten_array(el)
        }
        result = result.concat(el)
    }
    return result
}

console.log("Running Flattening Array")
arr = [[1, 2, [3]], 4]
flatten_result = flatten_array(arr)
console.log("Example Result", flatten_result)
console.log("Simple test \n",
    flatten_result, [1, 2, 3, 4], "\n",
    flatten_array([]), [], "\n",
    flatten_array([[[3, 4]]]), [3, 4])

// Parola più lunga
longest_word = 
    x => x
        .split(" ")
        .reduce(
            ((prev, curr) => prev.length < curr.length ? curr : prev),
            ""
        )

console.log("\nRunning Longest Word")
input_string = "Buongiorno mi chiamo Paolo"
console.log("Example Result", longest_word(input_string))
console.log("Simple test \n",
    longest_word("Ciao sono Alessandro"), "Alessandro", "\n",
    longest_word("") == "", "\n",
    longest_word("a b c"), "a",
)

// Intersezione tra array senza ripetizioni
intersection = (arrayA, arrayB) => [...new Set(arrayA.filter(el => arrayB.includes(el)))]

console.log("\nRunning Array Intersection")
console.log("Example Result", intersection([1, 5, 8, 5, 4, 9], [2, 5, 9, 0]))
console.log("Simple test\n",
    intersection([1, 2, 2, 3], [2, 2, 2]), [2], "\n",
    intersection([1, 2, 3], []), [], "\n",
    intersection([], []), [],
)