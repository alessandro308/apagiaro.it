<?php
    $json_array = file_get_contents('./stores.json');
    $warehouses = json_decode($json_array,true);
    $products = [];
    $id_to_name = Array();
    foreach($warehouses as $warehouse){
        foreach($warehouse["items"] as $item){
            $id = $item["id"];
            $name = ($item["name"] == NULL) ? ("Product # ".$id) : $item["name"];
            if( !in_array($id, $products) ){
                $products[] = $id;
                $id_to_name[$id] = $name;
            }
        }
    }

    function cmp($a, $b){
        global $id_to_name;
        return strcmp($id_to_name[$a], $id_to_name[$b]);
    }
    usort($products, "cmp");
?>
<!doctype html>
<html class="no-js" lang="">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <style>
            body {
                padding-top: 50px;
                padding-bottom: 20px;
            }
            .product{
                border: solid 1px gray;
                margin: 10px;
            }
            .hidden {
                display: none!important;
            }

        </style>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    </head>
    <body>
        <div class="container">
        <a href="index.php"><h1>GestioneMagazzino</h1></a>
        <h3>Gestione ristoccaggio magazzino</h3>
        <br/>
        <div class="input-group">
            <input type="text" class="form-control" placeholder="Di che cosa hai bisogno oggi?" id="search" aria-label="Recipient's username" aria-describedby="basic-addon2">
            <div class="input-group-append">
                <button class="btn btn-outline-secondary" type="button" id="submit_search">Cerca</button>
            </div>
        </div>
        <br/>
        <h3>Risultati</h3>
        <?php
            foreach( $products as $product ){ 
        ?>
        <div class="product row">
            <div class="col-9 align-self-center">
                <h3><? echo $id_to_name[$product]; ?></h3>
                <p>Qui va la descrizione del prodotto quindi ci metto un po' di testo</p>
            </div>
            <div class="col-3 align-self-center">
                <a 
                    class="btn btn-outline-secondary btn-block" 
                    type="button"
                    href="warehouses.php?id=<? echo $product?>"
                >
                    CTA
                </a>
            </div>
            </div>
        <?php
            }
        ?>
        </div>
      <!-- Bootstrap and J Query Scripts-->
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
        <script>
            function filter_product(e) {
                console.log("Filtering...")
                products = document.querySelectorAll(".product")
                products.forEach( product => {
                    if(
                        !product.querySelector("h3").textContent.toUpperCase().includes(e.target.value.toUpperCase()) &&
                        !product.querySelector("p").textContent.toUpperCase().includes(e.target.value.toUpperCase())
                    ){
                        if(!product.className.includes("hidden"))
                            product.className += " hidden";
                    }else{
                        product.className = "product row";
                    }
                })
            };
            document.getElementById("search").addEventListener('input', filter_product);
            document.getElementById("submit_search").addEventListener('click', filter_product);
        </script>
    </body>
</html>
